﻿using Newtonsoft.Json;

namespace Lytx_OM.ViewModel
{
    public class DescriptionInfoViewModel
    {
        public string Id { get; set; }

        [JsonProperty("Subject")]
        public string Subject { get; set; }

        [JsonProperty("Description")]
        public string Description { get; set; }

        [JsonProperty("Steps to Reproduce")]
        public string StepsToReproduce { get; set; }

        [JsonProperty("Internal Comments")]
        public string InternalComments { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
    }
}
