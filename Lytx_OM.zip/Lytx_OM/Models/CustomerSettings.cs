﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class CustomerSettings
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("HS Company ID")]
        public string HSCompanyID { get; set; }

        [JsonProperty("SafetyNet")]
        public string SafetyNet { get; set; }

        [JsonProperty("HS Company Name")]
        public string HSCompanyName { get; set; }

        [JsonProperty("Video Services")]
        public string VideoServices { get; set; }

        [JsonProperty("HS Group")]
        public string HSGroup { get; set; }

        [JsonProperty("Hub")]
        public string Hub { get; set; }

        [JsonProperty("Pod")]
        public string Pod { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [ForeignKey("MasterId")]
        public MasterClass MasterClass { get; set; }
    }
}
