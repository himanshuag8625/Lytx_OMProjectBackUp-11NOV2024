﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class InternalLytxInformation
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("Opportunity")]
        public string Opportunity { get; set; }

        [JsonProperty("Program Management")]
        public string ProgramManagement { get; set; }

        [JsonProperty("Related Project")]
        public string RelatedProject { get; set; }

        [JsonProperty("Principal Project")]
        public string PrincipalProject { get; set; }

        [JsonProperty("IPMC")]
        public string IPMC { get; set; }

        [JsonProperty("Principal Project Status")]
        public string PrincipalProjectStatus { get; set; }

        [JsonProperty("Installation")]
        public string Installation { get; set; }

        [JsonProperty("PP Backlog Debook Qty")]
        public string PPBacklogDebookQty { get; set; }

        [JsonProperty("PP Vers to be scheduled")]
        public string PPVersToBeScheduled { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [ForeignKey("MasterId")]
        public MasterClass MasterClass { get; set; }
    }
}
