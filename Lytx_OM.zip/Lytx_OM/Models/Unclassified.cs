﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class Unclassified
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("Account Health Indicator")]
        public string AccountHealthIndicator { get; set; }

        [JsonProperty("DOL Shutdown Date")]
        public string DOLShutdownDate { get; set; }

        [JsonProperty("Client Support Guidelines")]
        public string ClientSupportGuidelines { get; set; }

        [JsonProperty("Account Name")]
        public string AccountName { get; set; }

        [JsonProperty("Product Catalog Indicator")]
        public string ProductCatalogIndicator { get; set; }

        [JsonProperty("NPI Program Client")]
        public string NPIProgramClient { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [ForeignKey("MasterId")]
        public MasterClass MasterClass { get; set; }
    }
}
