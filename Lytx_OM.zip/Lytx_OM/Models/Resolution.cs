﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class Resolution
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("Event Found?")]
        public string EventFound { get; set; }

        [JsonProperty("Video Found - Event Number")]
        public string VideoFoundEventNumber { get; set; }

        [JsonProperty("Where found?")]
        public string WhereFound { get; set; }

        [JsonProperty("Root Cause")]
        public string RootCause { get; set; }

        [JsonProperty("Reason Not Found")]
        public string ReasonNotFound { get; set; }

        [JsonProperty("Resolution")]
        public string Resolution1 { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [ForeignKey("MasterId")]
        public MasterClass MasterClass { get; set; }
    }
}
