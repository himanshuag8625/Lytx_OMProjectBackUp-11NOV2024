﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class CaseFeedback
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("Feedback")]
        public string Feedback { get; set; }

        [JsonProperty("Coaching Complete")]
        public string CoachingComplete { get; set; }

        [JsonProperty("Feedback Type")]
        public string FeedbackType { get; set; }

        [JsonProperty("Agree/Disagree")]
        public string AgreeDisagree { get; set; }

        [JsonProperty("Feedback Note")]
        public string FeedbackNote { get; set; }

        [JsonProperty("Coach Notes")]
        public string CoachNotes { get; set; }

        [JsonProperty("Agent")]
        public string Agent { get; set; }

        [JsonProperty("Coached By")]
        public string CoachedBy { get; set; }

        [JsonProperty("Feedback By")]
        public string FeedbackBy { get; set; }

        [JsonProperty("Coached Date")]
        public string CoachedDate { get; set; }

        [JsonProperty("Feedback Date")]
        public string FeedbackDate { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [ForeignKey("MasterId")]
        public MasterClass MasterClass { get; set; }
    }
}
