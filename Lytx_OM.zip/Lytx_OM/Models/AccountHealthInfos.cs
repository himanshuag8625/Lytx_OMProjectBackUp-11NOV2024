﻿namespace Lytx_OM.Models
{
    public class AccountHealthInfos
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string AccountHealthIndicator { get; set; }
        public string AccountHealthInfo { get; set; }
        public string ClientSupportGuidelines { get; set; }
        public string DOLShutdownDate { get; set; }
        public string EndDate { get; set; }
        public int ImportSequenceNumber { get; set; }
        public string Name { get; set; }
        public string Owner { get; set; }
        public string RecordCreatedOn { get; set; }
        public string StartDate { get; set; }
        public string StatusReason { get; set; }
        public int TimeZoneRuleVersionNumber { get; set; }
        public string UserId { get; set; }
        public string UTCConversionTimeZoneCode { get; set; }
    }
}
