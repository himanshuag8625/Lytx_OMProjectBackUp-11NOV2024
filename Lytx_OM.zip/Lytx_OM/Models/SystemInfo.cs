﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class SystemInfo
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("Date/Time Opened")]
        public string DateTimeOpened { get; set; }

        [JsonProperty("Date/Time Closed")]
        public string DateTimeClosed { get; set; }

        [JsonProperty("Created By")]
        public string CreatedBy { get; set; }

        [JsonProperty("Last Modified By")]
        public string LastModifiedBy { get; set; }

        [JsonProperty("Hardware Rev")]
        public string HardwareRev { get; set; }

        [JsonProperty("Reminder - 10 Day")]
        public string Reminder10Day { get; set; }

        [JsonProperty("Business Reason")]
        public string BusinessReason { get; set; }

        [JsonProperty("Reminder - 14 day")]
        public string Reminder14Day { get; set; }

        [JsonProperty("Escalation Justification")]
        public string EscalationJustification { get; set; }

        [JsonProperty("Next Update Assigned To")]
        public string NextUpdateAssignedTo { get; set; }

        [JsonProperty("Entitlement Name")]
        public string EntitlementName { get; set; }

        [JsonProperty("Current User to Request Escalation")]
        public string CurrentUserToRequestEscalation { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [ForeignKey("MasterId")]
        public MasterClass MasterClass { get; set; }
    }
}
