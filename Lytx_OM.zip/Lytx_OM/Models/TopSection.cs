﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class TopSection
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        [JsonProperty("Case Owner")]
        public string CaseOwner { get; set; }

        [JsonProperty("Next Action Date")]
        public string NextActionDate { get; set; }

        [JsonProperty("Topic")]
        public string Topic { get; set; }

        [JsonProperty("Case Age")]
        public string CaseAge { get; set; }

        [JsonProperty("Category")]
        public string Category { get; set; }

        [JsonProperty("Case Age in Stage")]
        public string CaseAgeInStage { get; set; }

        [JsonProperty("Group")]
        public string Group { get; set; }

        [JsonProperty("State")]
        public string State { get; set; }

        [JsonProperty("Install Type")]
        public string InstallType { get; set; }

        [JsonProperty("Sub State")]
        public string SubState { get; set; }

        [JsonProperty("Parent Case")]
        public string ParentCase { get; set; }

        [JsonProperty("Case Record Type")]
        public string CaseRecordType { get; set; }

        [JsonProperty("Case Origin")]
        public string CaseOrigin { get; set; }

        [JsonProperty("Priority")]
        public string Priority { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [ForeignKey("MasterId")]
        public MasterClass MasterClass { get; set; }

    }
}
