﻿using Microsoft.Xrm.Sdk.Organization;
using Newtonsoft.Json;

namespace Lytx_OM.Models
{
    public class MasterClass
    {
        [JsonProperty("Id")]
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("CaseNo")]
        public string CaseNo { get; set; }

        [JsonProperty("ContactName")]
        public string ContactName { get; set; }

        [JsonProperty("AccountName")]
        public string AccountName { get; set; }

        [JsonProperty("Subject")]
        public string Subject { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("Priority")]
        public string Priority { get; set; }

        [JsonProperty("Location")]
        public string Location { get; set; }

        [JsonProperty("DateTimeOpened")]
        public string DateTimeOpened { get; set; }

        [JsonProperty("CaseOwnerAlias")]
        public string CaseOwnerAlias { get; set; }

        [JsonProperty("CaseRecordType")]
        public string CaseRecordType { get; set; }

        [JsonProperty("LasModifiedDate")]
        public string LasModifiedDate { get; set; }

        [JsonProperty("CaseOwnerName")]
        public string CaseOwnerName { get; set; }

        [JsonProperty("Escalated")]
        public string Escalated { get; set; }

        [JsonProperty("FirstMSOrderCloseDate")]
        public string FirstMSOrderCloseDate { get; set; }

        [JsonProperty("AccountSupportLevel")]
        public string AccountSupportLevel { get; set; }
        public string UserId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [JsonProperty("TopSection")]
        public TopSection TopSection { get; set; }

        [JsonProperty("CaseInfo")]
        public CaseInformation CaseInfo { get; set; }

        [JsonProperty("CustomerInfo")]
        public CustomerInfo CustomerInfo { get; set; }

        [JsonProperty("CustomerSettings")]
        public CustomerSettings CustomerSettings { get; set; }

        [JsonProperty("DescriptionInfo")]
        public DescriptionInfo DescriptionInfo { get; set; }

        [JsonProperty("InternalLytxInformation")]
        public InternalLytxInformation InternalLytxInformation { get; set; }

        [JsonProperty("SalesOpsItems")]
        public SalesOpsItems SalesOpsItems { get; set; }

        [JsonProperty("CaseFeedback")]
        public CaseFeedback CaseFeedback { get; set; }

        [JsonProperty("Resolution")]
        public Resolution Resolution { get; set; }

        [JsonProperty("SystemInfo")]
        public SystemInfo SystemInfo { get; set; }

        [JsonProperty("Unclassified")]
        public List<Unclassified> Unclassified { get; set; }
    }
}
