﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class DescriptionInfo
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        //public string Id { get; set; }

        [JsonProperty("Subject")]
        public string Subject { get; set; }

        [JsonProperty("Description")]
        public string Description { get; set; }

        [JsonProperty("Steps to Reproduce")]
        public string StepsToReproduce { get; set; }

        [JsonProperty("Internal Comments")]
        public string InternalComments { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

    }
}
