﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class CaseInformation
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("Type")]
        public string Type { get; set; }

        [JsonProperty("Scheduled Install Date Start")]
        public string ScheduledInstallDateStart { get; set; }

        [JsonProperty("Sub Type")]
        public string SubType { get; set; }

        [JsonProperty("Deal Margin")]
        public string DealMargin { get; set; }

        [JsonProperty("Options")]
        public string Options { get; set; }

        [JsonProperty("Processing Time Duration")]
        public string ProcessingTimeDuration { get; set; }

        [JsonProperty("Exceptions")]
        public string Exceptions { get; set; }

        [JsonProperty("Shipping Address")]
        public string ShippingAddress { get; set; }

        [JsonProperty("Exception Note")]
        public string ExceptionNote { get; set; }

        [JsonProperty("Return From Address")]
        public string ReturnFromAddress { get; set; }

        [JsonProperty("Division")]
        public string Division { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [ForeignKey("MasterId")]
        public MasterClass MasterClass { get; set; }
    }
}
