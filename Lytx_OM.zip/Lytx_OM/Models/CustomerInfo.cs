﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class CustomerInfo
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("Account Name")]
        public string AccountName { get; set; }

        [JsonProperty("Contact Name")]
        public string ContactName { get; set; }

        [JsonProperty("Account Manager")]
        public string AccountManager { get; set; }

        [JsonProperty("Contact Phone")]
        public string ContactPhone { get; set; }

        [JsonProperty("Location")]
        public string Location { get; set; }

        [JsonProperty("Contact Email")]
        public string ContactEmail { get; set; }

        [JsonProperty("VAR")]
        public string VAR { get; set; }

        [JsonProperty("Web Email")]
        public string WebEmail { get; set; }

        [JsonProperty("ARMA Approved")]
        public string ARMAApproved { get; set; }

        [JsonProperty("FRA Indicator")]
        public string FRAIndicator { get; set; }

        [JsonProperty("Hierarchy Authorized")]
        public string HierarchyAuthorized { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        
        [ForeignKey("MasterId")]
        public MasterClass MasterClass { get; set; }
    }
}
