﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations.Schema;

namespace Lytx_OM.Models
{
    public class SalesOpsItems
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        [JsonProperty("Sales Order #")]
        public string SalesOrder { get; set; }

        [JsonProperty("Invoice #")]
        public string Invoice { get; set; }

        [JsonProperty("SO Date")]
        public string SODate { get; set; }

        [JsonProperty("Invoice Date")]
        public string InvoiceDate { get; set; }

        [JsonProperty("Customer Bound Tracking Number")]
        public string CustomerBoundTrackingNumber { get; set; }

        [JsonProperty("Days to Issue SO")]
        public string DaysToIssueSO { get; set; }
        public string UserId { get; set; }
        public string MasterId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        [ForeignKey("MasterId")]
        public MasterClass MasterClass { get; set; }
    }
}
