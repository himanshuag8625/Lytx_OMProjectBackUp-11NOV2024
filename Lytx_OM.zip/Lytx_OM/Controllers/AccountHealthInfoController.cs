﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Lytx_OM.Models;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json.Linq;

namespace Lytx_OM.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AccountHealthInfoController : ControllerBase
    {
        private static List<DescriptionInfo> _records = new List<DescriptionInfo>();
        private readonly HttpClient _httpClient;
        private readonly string _insertFlowUrl = "https://prod-23.centralindia.logic.azure.com:443/workflows/a6be0bb669a74539a6674b8ebd15afce/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=0pPKDjll4WKrhmfRn5A6iS309swoixhtQDoCEdXlDqE";
        private readonly string _getFlowUrl = "https://prod-19.centralindia.logic.azure.com:443/workflows/9733148def394a40a8c33c47280c29ed/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=0qNB6icPhDp1BXAEk762irBCgwyNwQMq4BcXmpL8vAo";
        private readonly string _getFlowUrlById = "https://prod-02.centralindia.logic.azure.com:443/workflows/588cd202cf63491987380b5693034a25/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=4oOnJLlJNm3fk3ytIYkuPwaQYLFMz3P_RV0CQsTpkrI";
        private readonly string _updateFlowUrl = "https://prod-22.centralindia.logic.azure.com:443/workflows/b821fa2f66614fe3a2149383e244910c/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=1_3-yUhyCwa0dbByOXV_G8HfUqbHD7QP3W38EHCaj5s";
        private readonly string _deleteFlowUrl = "https://prod-31.centralindia.logic.azure.com:443/workflows/aec65dc4b96f4612b6c35ff457c5af61/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=BCgWVEeJ8-jD4tBw10wRn3rBxRQMEEig0OTSwc4lih0";

        public AccountHealthInfoController(HttpClient httpClient)
        {
            _httpClient = httpClient;
            LoadRecordsFromDataverse().Wait();
        }

        //private async Task LoadRecordsFromDataverse()
        //{
        //    try
        //    {
        //        // Create the JSON body if needed (modify according to your requirements)
        //        var jsonBody = new { }; // You can add properties here if needed
        //        var content = new StringContent(JsonConvert.SerializeObject(jsonBody), Encoding.UTF8, "application/json");

        //        // Send POST request to Power Automate or Dataverse API to fetch records
        //        var response = await _httpClient.PostAsync(_getFlowUrl, content);

        //        if (response.IsSuccessStatusCode)
        //        {
        //            // Read response content as JSON
        //            var json = await response.Content.ReadAsStringAsync();

        //            // Deserialize JSON into List<DescriptionInfo>
        //            var records = JsonConvert.DeserializeObject<List<DescriptionInfo>>(json);

        //            if (records != null)
        //            {
        //                _records = records; // Update your local record list
        //                Console.WriteLine("Records successfully loaded from Dataverse.");
        //            }
        //            else
        //            {
        //                Console.WriteLine("No records found in the response.");
        //            }
        //        }
        //        else
        //        {
        //            // Handle errors
        //            var errorContent = await response.Content.ReadAsStringAsync();
        //            Console.WriteLine($"Error fetching records: {response.StatusCode} - {response.ReasonPhrase}");
        //            Console.WriteLine($"Error details: {errorContent}");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"Exception occurred while loading records: {ex.Message}");
        //    }
        //}

        //private async Task LoadRecordsFromDataverse()
        //{
        //    try
        //    {
        //        // Create the JSON body if needed (modify according to your requirements)
        //        var jsonBody = new { }; // You can add properties here if needed
        //        var content = new StringContent(JsonConvert.SerializeObject(jsonBody), Encoding.UTF8, "application/json");

        //        // Send POST request to Power Automate or Dataverse API to fetch records
        //        var response = await _httpClient.PostAsync(_getFlowUrl, content);

        //        if (response.IsSuccessStatusCode)
        //        {
        //            // Read response content as JSON
        //            var json = await response.Content.ReadAsStringAsync();

        //            // Assuming the response JSON has a property "value" that contains the list of records
        //            var jsonObject = JObject.Parse(json);
        //            var valueArray = jsonObject["value"];

        //            // Deserialize JSON into List<DescriptionInfo> if valueArray exists
        //            if (valueArray != null && valueArray.HasValues)
        //            {
        //                // Map to your model
        //                var records = valueArray.ToObject<List<DescriptionInfo>>();

        //                if (records != null && records.Count > 0)
        //                {
        //                    _records = records; // Update your local record list
        //                    Console.WriteLine("Records successfully loaded from Dataverse.");
        //                }
        //                else
        //                {
        //                    Console.WriteLine("No records found in the response.");
        //                }
        //            }
        //            else
        //            {
        //                Console.WriteLine("The 'value' property is missing or empty in the response.");
        //            }
        //        }
        //        else
        //        {
        //            // Handle errors
        //            var errorContent = await response.Content.ReadAsStringAsync();
        //            Console.WriteLine($"Error fetching records: {response.StatusCode} - {response.ReasonPhrase}");
        //            Console.WriteLine($"Error details: {errorContent}");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"Exception occurred while loading records: {ex.Message}");
        //    }
        //}

        //private async Task LoadRecordsFromDataverse()
        //{
        //    try
        //    {
        //        // Create the JSON body if needed (modify according to your requirements)
        //        var jsonBody = new { }; // You can add properties here if needed
        //        var content = new StringContent(JsonConvert.SerializeObject(jsonBody), Encoding.UTF8, "application/json");

        //        // Send POST request to Power Automate or Dataverse API to fetch records
        //        var response = await _httpClient.PostAsync(_getFlowUrl, content);

        //        if (response.IsSuccessStatusCode)
        //        {
        //            // Read response content as JSON
        //            var jsonString = await response.Content.ReadAsStringAsync();
        //            var jsonObject = JObject.Parse(jsonString);
        //            var valueArray = jsonObject["value"]; // Assuming the records are in the "value" property

        //            // Ensure valueArray is not null or empty before looping
        //            if (valueArray != null && valueArray.HasValues)
        //            {
        //                var records = new List<DescriptionInfo>();

        //                // Loop through each record in the "value" array and map to your model
        //                foreach (var item in valueArray)
        //                {
        //                    if (item != null) // Check if item is not null before accessing properties
        //                    {
        //                        var record = new DescriptionInfo
        //                        {
        //                            Id = (string)item["cr6e3_name"], // Ensure correct casing
        //                            Subject = (string)item["cr6e3_subject"],
        //                            Description = (string)item["cr6e3_description"],
        //                            StepsToReproduce = (string)item["cr6e3_stepstoreproduce"],
        //                            InternalComments = (string)item["cr6e3_internalcomments"],
        //                            UserId = (string)item["cr6e3_userid"],
        //                            MasterId = (string)item["cr6e3_masterid"],
        //                            StartDate = item["cr6e3_startdate"]?.ToObject<DateTime>() ?? DateTime.MinValue, // Handle nullable dates
        //                            EndDate = item["cr6e3_enddate"]?.ToObject<DateTime>() ?? DateTime.MinValue
        //                        };

        //                        records.Add(record);
        //                    }
        //                }

        //                if (records.Count > 0)
        //                {
        //                    _records = records; // Update your local record list
        //                    Console.WriteLine("Records successfully loaded from Dataverse.");
        //                }
        //                else
        //                {
        //                    Console.WriteLine("No records found in the response.");
        //                }
        //            }
        //            else
        //            {
        //                Console.WriteLine("No records found in the response.");
        //            }
        //        }
        //        else
        //        {
        //            // Handle errors
        //            var errorContent = await response.Content.ReadAsStringAsync();
        //            Console.WriteLine($"Error fetching records: {response.StatusCode} - {response.ReasonPhrase}");
        //            Console.WriteLine($"Error details: {errorContent}");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.WriteLine($"Exception occurred while loading records: {ex.Message}\n{ex.StackTrace}");
        //    }
        //}


        private async Task LoadRecordsFromDataverse()
        {
            try
            {
                // Create the JSON body if needed (modify according to your requirements)
                var jsonBody = new { }; // You can add properties here if needed
                var content = new StringContent(JsonConvert.SerializeObject(jsonBody), Encoding.UTF8, "application/json");

                // Send POST request to Power Automate or Dataverse API to fetch records
                var response = await _httpClient.PostAsync(_getFlowUrl, content);

                if (response.IsSuccessStatusCode)
                {
                    // Read response content as JSON
                    var jsonString = await response.Content.ReadAsStringAsync();

                    // Parse the response JSON, assuming it could be an array
                    JArray jsonArray = JArray.Parse(jsonString);

                    if (jsonArray != null && jsonArray.HasValues)
                    {
                        var records = new List<DescriptionInfo>();

                        // Loop through each record in the array and map to your model
                        foreach (var item in jsonArray)
                        {
                            if (item != null && item.Type == JTokenType.Object) // Ensure item is an object
                            {
                                var record = new DescriptionInfo
                                {
                                    Id = (string)item["cr6e3_name"], // Ensure correct casing
                                    Subject = (string)item["cr6e3_subject"],
                                    Description = (string)item["cr6e3_description"],
                                    StepsToReproduce = (string)item["cr6e3_stepstoreproduce"],
                                    InternalComments = (string)item["cr6e3_internalcomments"],
                                    UserId = (string)item["cr6e3_userid"],
                                    MasterId = (string)item["cr6e3_masterid"],
                                    StartDate = item["cr6e3_startdate"]?.ToObject<DateTime>() ?? DateTime.MinValue, // Handle nullable dates
                                    EndDate = item["cr6e3_enddate"]?.ToObject<DateTime>() ?? DateTime.MinValue
                                };

                                records.Add(record);
                            }
                        }

                        if (records.Count > 0)
                        {
                            _records = records; // Update your local record list
                            Console.WriteLine("Records successfully loaded from Dataverse.");
                        }
                        else
                        {
                            Console.WriteLine("No records found in the response.");
                        }
                    }
                    else
                    {
                        Console.WriteLine("No records found in the response.");
                    }
                }
                else
                {
                    // Handle errors
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Console.WriteLine($"Error fetching records: {response.StatusCode} - {response.ReasonPhrase}");
                    Console.WriteLine($"Error details: {errorContent}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception occurred while loading records: {ex.Message}\n{ex.StackTrace}");
            }
        }





        // GET: api/AccountHealthInfo
        [HttpGet] // Specify that this method handles GET requests
        public IActionResult GetAllAccountHealthRecords()
        {
            return Ok(_records);
        }

        // POST: api/AccountHealthInfo
        [HttpPost] // Specify that this method handles POST requests
        public async Task<IActionResult> CreateAccountHealth([FromBody] DescriptionInfo record)
        {
            if (record == null) return BadRequest("Invalid data.");
            DescriptionInfo desc = new DescriptionInfo
            {
                //Id = Guid.NewGuid().ToString(),
                Subject = record.Subject,
                Description = record.Description,
                StepsToReproduce = record.StepsToReproduce,
                InternalComments = record.InternalComments,
                UserId = record.UserId,
                MasterId = record.MasterId,
                StartDate = record.StartDate,
                EndDate = record.EndDate
            };

            // Check if the record already exists
            if (RecordExists(record.Subject, record.MasterId))
            {
                return Conflict("Subject already added..!!!");
            }

            // Optional: Call the Power Automate flow here if needed
            var response = await CallPowerAutomateFlow(desc);
            if (!response.IsSuccessStatusCode)
            {
                return StatusCode((int)response.StatusCode, "Failed to call Power Automate flow.");
            }

            // Assuming record.Id is generated from the flow or manually assigned
            _records.Add(desc);
            return CreatedAtAction(nameof(GetAllAccountHealthRecords), new { id = desc.Id }, desc);
        }

        // Call the Power Automate Flow
        private async Task<HttpResponseMessage> CallPowerAutomateFlow(DescriptionInfo record)
        {
            var json = JsonConvert.SerializeObject(record);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            return await _httpClient.PostAsync(_insertFlowUrl, content);
        }

        // Check if the record already exists
        private bool RecordExists(string subject, string masterId)
        {
            // Assuming _records is a list of DescriptionInfo
            return _records.Any(r => r.Subject == subject && r.MasterId == masterId);
        }


        // GET: api/AccountHealthInfo/{id}
        [HttpGet("{id}")]
        public IActionResult GetAccountHealthById(string id)
        {
            var record = _records.FirstOrDefault(r => r.Id == id);
            if (record == null) return NotFound();

            return Ok(record);
        }

        //// PUT: api/AccountHealthInfo/{id}
        //[HttpPut("{id}")]
        //public IActionResult UpdateAccountHealth(string id, [FromBody] DescriptionInfo updatedRecord)
        //{
        //    // Validate input
        //    if (string.IsNullOrEmpty(id) || updatedRecord == null)
        //    {
        //        return BadRequest("Invalid data.");
        //    }

        //    // Find the existing record
        //    var record = _records.FirstOrDefault(r => r.Id == id);
        //    if (record == null)
        //    {
        //        return NotFound($"No record found with Id = {id}.");
        //    }

        //    // Update logic (exclude fields that shouldn't be updated, like Id, if necessary)
        //    record.Subject = updatedRecord.Subject;
        //    record.Description = updatedRecord.Description;
        //    record.StepsToReproduce = updatedRecord.StepsToReproduce;
        //    record.InternalComments = updatedRecord.InternalComments;
        //    // Optional: If UserId and MasterId should not change, remove these updates
        //    record.UserId = updatedRecord.UserId;
        //    record.MasterId = updatedRecord.MasterId;

        //    // Optionally, return the updated record
        //    return Ok(record); // 200 OK with the updated record
        //}

        // PUT: api/AccountHealthInfo/{id}
        //[HttpPut("{id}")]
        //public async Task<IActionResult> UpdateAccountHealth(string id, [FromBody] DescriptionInfo updatedRecord)
        //{
        //    // Validate input
        //    if (string.IsNullOrEmpty(id) || updatedRecord == null)
        //    {
        //        return BadRequest("Invalid data.");
        //    }

        //    // Find the existing record
        //    var record = _records.FirstOrDefault(r => r.Id == id);
        //    if (record == null)
        //    {
        //        return NotFound($"No record found with Id = {id}.");
        //    }

        //    // Call the Power Automate flow for update
        //    var response = await CallPowerAutomateFlow(updatedRecord, _updateFlowUrl);
        //    if (!response.IsSuccessStatusCode)
        //    {
        //        return StatusCode((int)response.StatusCode, "Failed to call Power Automate flow for update.");
        //    }

        //    // Update local record with the new values
        //    record.Subject = updatedRecord.Subject;
        //    record.Description = updatedRecord.Description;
        //    record.StepsToReproduce = updatedRecord.StepsToReproduce;
        //    record.InternalComments = updatedRecord.InternalComments;

        //    // Optional: If UserId and MasterId should not change, remove these updates
        //    record.UserId = updatedRecord.UserId;
        //    record.MasterId = updatedRecord.MasterId;

        //    // Return the updated record
        //    return Ok(record); // 200 OK with the updated record
        //}

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateAccountHealth(string id, [FromBody] DescriptionInfo updatedRecord)
        {
            // Validate input
            if (string.IsNullOrEmpty(id) || updatedRecord == null)
            {
                return BadRequest("Invalid data.");
            }

            // Find the existing record
            var existingRecord = _records.FirstOrDefault(r => r.Id == id);
            if (existingRecord == null)
            {
                return NotFound($"No record found with Id = {id}.");
            }

            // Call the Power Automate flow for the update
            var response = await CallPowerAutomateFlow(updatedRecord, _updateFlowUrl);
            if (!response.IsSuccessStatusCode)
            {
                var errorMessage = await response.Content.ReadAsStringAsync();
                return StatusCode((int)response.StatusCode, $"Failed to call Power Automate flow for update: {errorMessage}");
            }

            // Update the local record with the new values
            existingRecord.Subject = updatedRecord.Subject;
            existingRecord.Description = updatedRecord.Description;
            existingRecord.StepsToReproduce = updatedRecord.StepsToReproduce;
            existingRecord.InternalComments = updatedRecord.InternalComments;

            // Optional: If UserId and MasterId should not change, you can choose to not update them
            existingRecord.UserId = updatedRecord.UserId;
            existingRecord.MasterId = updatedRecord.MasterId;

            // Return the updated record
            return Ok(existingRecord); // Return 200 OK with the updated record
        }


        // Call the Power Automate Flow for update
        private async Task<HttpResponseMessage> CallPowerAutomateFlow(DescriptionInfo record, string url)
        {
            var json = JsonConvert.SerializeObject(record);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            return await _httpClient.PutAsync(url, content);
        }

        //// DELETE: api/AccountHealthInfo/{id}
        //[HttpDelete("{id}")]
        //public async Task<IActionResult> DeleteAccountHealth(string id)
        //{
        //    // Check if the record exists
        //    var record = _records.FirstOrDefault(r => r.Id == id);

        //    if (record == null)
        //    {
        //        return NotFound(); // 404 Not Found if the record doesn't exist
        //    }

        //    // Remove the record from the collection
        //    _records.Remove(record);

        //    // Optionally, if interacting with a database, ensure the deletion is asynchronous
        //    // await _dbContext.SaveChangesAsync();

        //    return NoContent(); // 204 No Content after successful deletion
        //}

        // DELETE: api/AccountHealthInfo/{id}
        // DELETE: api/AccountHealthInfo/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAccountHealth(string id)
        {
            // Check if the record exists
            var existingRecord = _records.FirstOrDefault(r => r.Id == id);

            if (existingRecord == null)
            {
                return NotFound($"No record found with Id = {id}."); // 404 Not Found if the record doesn't exist
            }

            // Call the Power Automate flow for deletion before removing the local record
            var response = await CallPowerAutomateFlowForDelete(existingRecord);
            if (!response.IsSuccessStatusCode)
            {
                var errorMessage = await response.Content.ReadAsStringAsync();
                return StatusCode((int)response.StatusCode, $"Failed to call Power Automate flow for deletion: {errorMessage}");
            }

            // Remove the record from the local collection only after successful deletion via flow
            _records.Remove(existingRecord);

            return NoContent(); // 204 No Content after successful deletion
        }

        // Helper method to call the Power Automate Flow for delete
        private async Task<HttpResponseMessage> CallPowerAutomateFlowForDelete(DescriptionInfo record)
        {
            var json = JsonConvert.SerializeObject(record);
            var content = new StringContent(json, Encoding.UTF8, "application/json");

            return await _httpClient.PostAsync(_deleteFlowUrl, content);
        }

    }
}
